import pandas as pd
import sys
import os

try:
    #todo 1. Read the cleaned Excel file
    input_file_Location_Value = "Employees_Cleaned.xlsx"
    if not os.path.exists(input_file_Location_Value):
        raise FileNotFoundError(f"Input file not found: {input_file_Location_Value}")

    Cleaned_DT_Values = pd.read_excel(input_file_Location_Value)

    # todo Validate required columns
    required_cols = ["Company", "Email"]
    for col in required_cols:
        if col not in Cleaned_DT_Values.columns:
            raise KeyError(f"Missing required column: {col}")

    # Todo 2. Count unique companies
    unique_companies_Values = Cleaned_DT_Values["Company"].nunique()

    #todo 3. Top 5 most common email domains
    Cleaned_DT_Values["EmailDomain"] = Cleaned_DT_Values["Email"].astype(str).str.split("@").str[-1]
    top_domains = Cleaned_DT_Values["EmailDomain"].value_counts().head(5)

    #todo 4. Count employees per company
    employees_per_company = Cleaned_DT_Values["Company"].value_counts()

    #todo 5. Save summary into CSV
    output_file = "Summary_Report.csv"
    with open(output_file, "w", encoding="utf-8") as f:
        f.write("Aspect,Value\n")
        f.write(f"Unique Companies,{unique_companies_Values}\n\n")

        f.write("Top 5 Email Domains:\n")
        for domain, count in top_domains.items():
            f.write(f"{domain},{count}\n")
        f.write("\n")

        f.write("Employees per Company:\n")
        for company, count in employees_per_company.items():
            f.write(f"{company},{count}\n")

    print(f"Report generated successfully: {output_file}")

except FileNotFoundError as e:
    print(e)
    sys.exit(1)

except KeyError as e:
    print(e)
    sys.exit(1)

except Exception as e:
    print(f"Unexpected error: {e}")
    sys.exit(1)